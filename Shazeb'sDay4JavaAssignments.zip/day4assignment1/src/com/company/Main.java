package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Avengers[] avengers = new Avengers[5];
//  creating space and getting details for avengers
        for (int i = 0; i < 5; i++) {
            avengers[i] = new Avengers();
            avengers[i].getDetails();
        }
        for (int i = 0; i < 5; i++) {
            avengers[i].displayDetails();
        }
    }
}
