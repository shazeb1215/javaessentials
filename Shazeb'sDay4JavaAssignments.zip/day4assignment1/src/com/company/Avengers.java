package com.company;

import java.util.Scanner;

public class Avengers {

    Scanner sc = new Scanner(System.in);

    String name;
    int age;
    String power;
    String weapon;
    String planet;

    public void getDetails(){
        System.out.println("Enter name of the avenger :");
        name= sc.nextLine();
        System.out.println("Age of "+name+" is :");
        age= sc.nextInt();
        sc.nextLine();
        System.out.println("Power of "+name+" is :");
        power= sc.nextLine();
        System.out.println("weapon of "+name+" is :");
        weapon= sc.nextLine();
        System.out.println(name+" is from planet :");
        planet= sc.nextLine();
    }

    public void displayDetails(){
        System.out.println("Name of avenger is "+name);
        System.out.println("Age of "+name+" is "+age);
        System.out.println("Power of "+name+" is "+power);
        System.out.println("weapon of "+name+" is "+age);
        System.out.println(name+" is from planet "+planet);
    }

}
