package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int sum = 0;
        int a[] = new int[5];
        System.out.println("Enter the elements:");
        for (int i = 0; i < 5; i++)
        {
            a[i] = sc.nextInt();
        }
        for (int i = 0; i < 5; i++){
            sum = sum +a[i];
        }
        System.out.println("Sum of all the values is "+sum);

    }
}