package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m1,m2,m3,m4,m5;
        float percentage;

        System.out.println("Enter the marks of subject 1 :");
        m1= sc.nextInt();
        System.out.println("Enter the marks of subject 2 :");
        m2= sc.nextInt();
        System.out.println("Enter the marks of subject 3 :");
        m3= sc.nextInt();
        System.out.println("Enter the marks of subject 4 :");
        m4= sc.nextInt();
        System.out.println("Enter the marks of subject 5 :");
        m5= sc.nextInt();

        percentage = (float) ((m1+m2+m3+m4+m5)/5.0);
        System.out.println("percentage of student is "+percentage+" %");

        if(percentage<=100 && percentage>90){
            System.out.println("Student secured grade A+");
        }
        else if(percentage<=90 && percentage>80){
            System.out.println("Student secured grade A");
        }
        else if(percentage<=80 && percentage>70){
            System.out.println("Student secured grade B+");
        }
        else if(percentage<=70 && percentage>60){
            System.out.println("Student secured grade B");
        }
        else if(percentage<=60 && percentage>50){
            System.out.println("Student secured grade C+");
        }
        else if(percentage<=50 && percentage>40){
            System.out.println("Student secured grade C");
        }
        else {
            System.out.println("Student is failed");
        }


    }
}
