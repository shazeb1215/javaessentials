package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String name;
        int date,month,year,y,y2;
        double monthly_salary,salary,tax_amount;
        System.out.println("Enter name of the employee :");
        name= sc.nextLine();
        System.out.println("Enter the date of birth of "+name);
        date=sc.nextInt();
        System.out.println("Enter the birth month of "+name);
        month=sc.nextInt();
        System.out.println("Enter the birth year of "+name);
        year=sc.nextInt();
        System.out.println("Enter the monthly salary "+name);
        monthly_salary=sc.nextDouble();
        
        y= 2020-year;
        y2=2019-year;

        if(date-10>0){
            if(month-10>0){
                System.out.println("Age of "+name+" is "+y2);
            }
            else{
                System.out.println("Age of "+name+" is "+y);
            }
        }
        else{
            if(month-10>0){
                System.out.println("Age of "+name+" is "+y2);
            }
            else{
                System.out.println("Age of "+name+" is "+y);
            }
        }
        salary = monthly_salary*12;
        System.out.println("Yearly salary of "+name+" is "+salary);

        if(salary>=500000 ){
            System.out.println("taxamount to be paid by "+name+" is "+salary/5);
        }
        else if(salary>=400000 && salary<500000){
            System.out.println("taxamount to be paid by "+name+" is "+salary*0.15);
        }
        else if(salary>=300000 && salary<400000){
            System.out.println("taxamount to be paid by "+name+" is "+salary/10);
        }
        else if(salary>=200000 && salary<300000){
            System.out.println("taxamount to be paid by "+name+" is "+salary/20);
        }
        else{
            System.out.println("No tax amount to be paid by "+name);
        }

    }
}
