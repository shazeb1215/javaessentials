package com.quizapp;

import java.util.Scanner;

public class Question {
    Scanner sc = new Scanner(System.in);
    String question, option1, option2, option3, option4;
    boolean op5 = true, op6 = false;
    int correctAns, userAns, hintreq;


    public boolean askQuestion() {
        System.out.println(question);
        System.out.println("1) " + option1);
        System.out.println("2) " + option2);
        System.out.println("3) " + option3);
        System.out.println("4) " + option4);
//        System.out.println("Do you want a hint ? ");
        System.out.println("Would you like to answer or skip the question :");
        System.out.println("1) skip the question");
        System.out.println("2) I would like to answer.");
        hintreq = sc.nextInt();

        switch (hintreq) {
            case 1:
                if (hintreq == 1) {
                    Hints hints = new Hints();
                    Hints.hint();
                }
                break;
            default:
                continue;

        }
        System.out.println("option you would like to chose");
        userAns = sc.nextInt();

        if (userAns == correctAns) {
            return true;
        }
        return false;
    }
}
