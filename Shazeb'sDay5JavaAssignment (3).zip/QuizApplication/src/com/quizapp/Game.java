package com.quizapp;

public class Game {

    Player player=new Player();
    Question[] questions = new Question[3];
    String[] questionsdata={"Who is the strongest Avenger?","What is the closest planet to sun?","What is the capital of Australia?"};
    String[] option1 = {"Ironman","Mercury","Sydney"};
    String[] option2 = {"Thor","Venus","Melbourne"};
    String[] option3 = {"Hulk","Earth","Perth"};
    String[] option4 = {"Dr Strange","Mars","Canberra"};
    int[] correctAns = {2,1,4};


    public void initGame()
    {
        for(int i=0;i<3;i++)
        {
            //creating space for questions
            questions[i]=new Question();
        }


        //applying values to the variABLES OF THE OBJECT
//        questions[0].question="Who is the strongest Avenger?";
//        questions[0].option1="Ironman";
//        questions[0].option2="Thor";
//        questions[0].option3="Hulk";
//        questions[0].option4="Dr Strange";
//
//        questions[0].correctAns = 2;
//
//        questions[1].question="What is the closest planet to sun?";
//        questions[1].option1="Mercury";
//        questions[1].option2="Venus";
//        questions[1].option3="Earth";
//        questions[1].option4="Mars";
//        questions[1].correctAns = 1;
//
//        questions[2].question="What is the capital of Australia?";
//        questions[2].option1="Sydney";
//        questions[2].option2="Melbourne";
//        questions[2].option3="Perth";
//        questions[2].option4="Canberra";
//        questions[2].correctAns = 4;
        for (int i=0;i<3;i++)
        {

            questions[i].question=questionsdata[i];
            questions[i].option1=option1[i];
            questions[i].option2=option2[i];
            questions[i].option3=option3[i];
            questions[i].option4=option4[i];
            questions[i].correctAns = correctAns[i];

        }

    }
    public void play()
    {
        player.getDetails();
        for (int i=0;i<3;i++)
        {
            boolean status = questions[i].askQuestion();
            if(status==true)
            {
                System.out.println("amazing selection, your answer is correct.");
                player.score++;
            }
            else
            {
                System.out.println("Sorry , you chose the incorrect answer ,but you played very well.");
            }
        }
        System.out.println(player.name+" your score is "+player.score);

    }
}
