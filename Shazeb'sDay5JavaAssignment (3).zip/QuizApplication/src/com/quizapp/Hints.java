package com.quizapp;
import java.util.Scanner;

public class Hints {
    static Scanner sc = new Scanner(System.in);

    public static void hint()
    {
        int num;

//        System.out.println("The hint you would like to chose:");
//        System.out.println("1) 50-50");
//        System.out.println("2) skip the question");
//        num =sc.nextInt();
//
//        if (num == 1) {
//            System.out.println("you have chosen for the hint 50-50");
//            System.out.println("Now your 2 incorrect options are removed. Now you have to chose from the remaining 2 options and answer according to old option no. :");
//
//        }
    }

}