package com.company;

public class Employee {
    String name;
    int age;
    String city;

    public void display(){
        System.out.println("Name of employee is "+name);
        System.out.println("Age of "+name+" is "+age);
        System.out.println(name+" lives in "+city);
    }

}
